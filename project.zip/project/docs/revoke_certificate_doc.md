# revoke_certificate.py

## Purpose
Handles revocation of certificates by adding them to the CRL.

## Features
- Adds revoked certificates with serial numbers to the CRL.
- Supports specifying revocation reasons.

## How It Works
1. Load the root certificate and private key.
2. Add serial numbers to the CRL.
3. Sign the CRL with the root private key.
4. Save the CRL in the `crl` directory.

## Usage
Run the script and provide the serial number of the certificate to be revoked.

