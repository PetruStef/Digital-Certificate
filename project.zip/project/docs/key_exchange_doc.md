# key_exchange.py

## Purpose
Implements key exchange functionality using Elliptic Curve Diffie-Hellman (ECDH).

## Features
- Establishes a shared secret between two parties using ECC keys.
- Enables secure symmetric encryption.

## How It Works
1. Load private and public keys of both parties.
2. Perform ECDH to compute a shared secret.
3. Use the shared secret for AES encryption.

## Usage
Run the script to perform secure key exchange.

