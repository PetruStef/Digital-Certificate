# generate_crl.py

## Purpose
This script generates a Certificate Revocation List (CRL) to manage revoked certificates.

## Features
- Adds revoked certificates to the CRL using their serial numbers.
- Signs the CRL with the root private key to ensure authenticity.
- Saves the CRL in PEM format.

## How It Works
1. Load the root certificate and private key.
2. Add serial numbers of revoked certificates to the CRL.
3. Define `last_update` and `next_update` fields for the CRL.
4. Sign the CRL with the root private key.
5. Save the CRL in the `crl` directory.

## Usage
Execute the script and provide the serial numbers of revoked certificates.

