# generate_root.py

## Purpose
This script generates a self-signed root certificate.

## Features
- Creates a root certificate using RSA/ECC keys.
- Configurable expiration period.
- Saves the root certificate and private key in PEM format.

## How It Works
1. Generate an ECC private key.
2. Define certificate attributes (country, organization, common name).
3. Build and sign the certificate.
4. Save the certificate and key in the `certificates` directory.

## Usage
Run the script to generate the root certificate.

