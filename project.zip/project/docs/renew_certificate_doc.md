# renew_certificate.py

## Purpose
Renews certificates before expiration.

## Features
- Issues a new certificate with updated validity period.
- Retains the original subject attributes.

## How It Works
1. Load the expired certificate.
2. Create a new certificate with updated expiration.
3. Sign the certificate using the root private key.
4. Save the renewed certificate in the `certificates` directory.

## Usage
Run the script to renew an expired or soon-to-expire certificate.

