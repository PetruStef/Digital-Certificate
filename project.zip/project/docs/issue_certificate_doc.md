# issue_certificate.py

## Purpose
Issues derived certificates from the root certificate.

## Features
- Creates a certificate containing public key, serial number, and expiration date.
- Signs certificates with the root private key.

## How It Works
1. Load the root certificate and private key.
2. Generate a new key pair for the derived certificate.
3. Build the certificate with subject attributes.
4. Sign the certificate using the root private key.
5. Save the issued certificate in the `certificates` directory.

## Usage
Run the script to issue a certificate with the desired attributes.

