# verify_certificates.py

## Purpose
Validates certificates for expiration, signature, and revocation.

## Features
- Checks certificate validity period.
- Verifies signature against the issuer’s public key.
- Ensures the certificate is not in the CRL.

## How It Works
1. Load the certificate to validate.
2. Verify the signature using the issuer’s public key.
3. Check the CRL for the certificate’s serial number.

## Usage
Run the script to validate a certificate.

