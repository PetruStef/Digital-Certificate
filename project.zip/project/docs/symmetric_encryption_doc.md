# symmetric_encryption.py

## Purpose
Implements symmetric encryption and decryption using AES.

## Features
- Encrypts plaintext using AES-CBC mode.
- Decrypts ciphertext back to plaintext.

## How It Works
1. Derive an AES key from the shared secret.
2. Encrypt data using the AES key.
3. Decrypt data using the same key.

## Usage
Run the script to encrypt or decrypt data.

