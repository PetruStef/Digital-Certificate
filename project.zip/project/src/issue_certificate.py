# Script for issuing certificates
import os
from cryptography import x509
from cryptography.x509.oid import NameOID
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa, ec
import datetime

def issue_certificate(subject_name, issuer_cert, issuer_key, key_type="ECC", expiration_date="2025-01-01"):
    # Ensure the 'certificates' directory exists
    cert_dir = os.path.join(os.path.dirname(__file__), '..', 'certificates')
    os.makedirs(cert_dir, exist_ok=True)

    # Generate private key based on specified type
    if key_type.upper() == "RSA":
        private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048,
        )
    elif key_type.upper() == "ECC":
        private_key = ec.generate_private_key(ec.SECP384R1())
    else:
        raise ValueError("Unsupported key type. Choose either 'RSA' or 'ECC'.")

    # Define certificate details for the issued certificate
    subject = x509.Name([
        x509.NameAttribute(NameOID.COUNTRY_NAME, u"RO"),
        x509.NameAttribute(NameOID.STATE_OR_PROVINCE_NAME, u"Timiș"),
        x509.NameAttribute(NameOID.LOCALITY_NAME, u"Timișoara"),
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, u"Cybersecurity"),
        x509.NameAttribute(NameOID.COMMON_NAME, subject_name),
    ])

    # Parse the expiration date
    not_valid_after = datetime.datetime.strptime(expiration_date, "%Y-%m-%d")

    # Build the issued certificate
    issued_certificate = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer_cert.subject)
        .public_key(private_key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(datetime.datetime.utcnow())
        .not_valid_after(not_valid_after)
        .add_extension(
            x509.SubjectKeyIdentifier.from_public_key(private_key.public_key()),
            critical=False,
        )
        .add_extension(
            x509.BasicConstraints(ca=False, path_length=None),
            critical=True,
        )
        .sign(issuer_key, hashes.SHA256())
    )

    # Save the issued certificate and private key to files
    cert_file_name = f"{subject_name.replace(' ', '_')}_certificate.pem"
    key_file_name = f"{subject_name.replace(' ', '_')}_private_key.pem"

    with open(os.path.join(cert_dir, cert_file_name), "wb") as f:
        f.write(issued_certificate.public_bytes(serialization.Encoding.PEM))

    with open(os.path.join(cert_dir, key_file_name), "wb") as f:
        f.write(private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.TraditionalOpenSSL,
            encryption_algorithm=serialization.NoEncryption()
        ))

if __name__ == "__main__":
    # Load the root certificate and private key
    with open(os.path.join(os.path.dirname(__file__), '..', 'certificates', 'root_certificate.pem'), "rb") as f:
        root_cert_data = f.read()
    root_certificate = x509.load_pem_x509_certificate(root_cert_data)

    with open(os.path.join(os.path.dirname(__file__), '..', 'certificates', 'root_private_key.pem'), "rb") as f:
        root_key_data = f.read()
    root_private_key = serialization.load_pem_private_key(root_key_data, password=None)

    # Ask for subject common name, key type, and expiration date
    subject_name = input("Enter subject common name: ").strip()
    key_type = input("Enter key type (RSA/ECC): ").strip()
    expiration_date = input("Enter expiration date (YYYY-MM-DD): ").strip()

    try:
        # Validate the expiration date format
        datetime.datetime.strptime(expiration_date, "%Y-%m-%d")
        issue_certificate(subject_name, root_certificate, root_private_key, key_type, expiration_date)
    except ValueError:
        print("Invalid date format. Please enter the expiration date in the format YYYY-MM-DD.")
