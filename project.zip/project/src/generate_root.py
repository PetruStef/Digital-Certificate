import os
from cryptography import x509
from cryptography.x509.oid import NameOID
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa, ec
import datetime

def generate_root_certificate(key_type="ECC", expiration_date="2027-01-01"):
    # Ensure the 'certificates' directory exists
    cert_dir = os.path.join(os.path.dirname(__file__), '..', 'certificates')
    os.makedirs(cert_dir, exist_ok=True)

    # Generate private key based on specified type
    if key_type.upper() == "RSA":
        private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048,
        )
    elif key_type.upper() == "ECC":
        private_key = ec.generate_private_key(ec.SECP384R1())
    else:
        raise ValueError("Unsupported key type. Choose either 'RSA' or 'ECC'.")

    # Define certificate details
    subject = issuer = x509.Name([
        x509.NameAttribute(NameOID.COUNTRY_NAME, u"RO"),
        x509.NameAttribute(NameOID.STATE_OR_PROVINCE_NAME, u"Timiș"),
        x509.NameAttribute(NameOID.LOCALITY_NAME, u"Timișoara"),
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, u"Cybersecurity"),
        x509.NameAttribute(NameOID.COMMON_NAME, u"Cyber.ro"),
    ])

    # Parse the expiration date
    not_valid_after = datetime.datetime.strptime(expiration_date, "%Y-%m-%d")

    # Build the self-signed root certificate
    root_certificate = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(private_key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(datetime.datetime.utcnow())
        .not_valid_after(not_valid_after)
        .add_extension(
            x509.SubjectKeyIdentifier.from_public_key(private_key.public_key()),
            critical=False,
        )
        .add_extension(
            x509.BasicConstraints(ca=True, path_length=None),
            critical=True,
        )
        .sign(private_key, hashes.SHA256())
    )

    # Save the root certificate and private key to files
    with open(os.path.join(cert_dir, "root_certificate.pem"), "wb") as f:
        f.write(root_certificate.public_bytes(serialization.Encoding.PEM))

    with open(os.path.join(cert_dir, "root_private_key.pem"), "wb") as f:
        f.write(private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.TraditionalOpenSSL,
            encryption_algorithm=serialization.NoEncryption()
        ))

if __name__ == "__main__":
    # Ask for key type
    key_type = input("Enter key type (RSA/ECC): ").strip()
    
    # Ask for expiration date
    expiration_date = input("Enter expiration date (YYYY-MM-DD): ").strip()

    try:
        # Validate the expiration date format
        datetime.datetime.strptime(expiration_date, "%Y-%m-%d")
        generate_root_certificate(key_type, expiration_date)
    except ValueError:
        print("Invalid date format. Please enter the expiration date in the format YYYY-MM-DD.")
