import os
from cryptography.hazmat.primitives.asymmetric import rsa, ec, padding
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
import secrets
import datetime
from cryptography import x509
from cryptography.hazmat.backends import default_backend

# Load and verify certificates functions
def load_certificate(file_path):
    print(f"Loading certificate from {file_path}")
    with open(file_path, "rb") as f:
        cert_data = f.read()
    return x509.load_pem_x509_certificate(cert_data, default_backend())

def load_crl(file_path):
    print(f"Loading CRL from {file_path}")
    if os.path.exists(file_path):
        with open(file_path, "rb") as f:
            crl_data = f.read()
        return x509.load_pem_x509_crl(crl_data, default_backend())
    return None

def verify_certificate(cert_path, crl_path):
    try:
        cert = load_certificate(cert_path)
        current_time = datetime.datetime.now(datetime.timezone.utc)

        # Check if the certificate is expired or not yet valid
        if cert.not_valid_after_utc < current_time:
            print(f"Certificate {cert_path} is expired.")
            return False
        if cert.not_valid_before_utc > current_time:
            print(f"Certificate {cert_path} is not yet valid.")
            return False

        # Check if the certificate has been revoked
        crl = load_crl(crl_path)
        if crl and crl.get_revoked_certificate_by_serial_number(cert.serial_number):
            print(f"Certificate {cert_path} has been revoked.")
            return False

        print(f"Certificate {cert_path} is valid and not revoked.")
        return True
    except Exception as e:
        print(f"Failed to verify certificate {cert_path}: {e}")
        return False

# Key exchange functions
def load_private_key(file_path):
    print(f"Loading private key from {file_path}")
    try:
        with open(file_path, "rb") as f:
            key_data = f.read()
        return serialization.load_pem_private_key(key_data, password=None, backend=default_backend())
    except Exception as e:
        print(f"Failed to load private key from {file_path}: {e}")
        return None

def load_public_key_from_cert(file_path):
    print(f"Loading public key from certificate {file_path}")
    try:
        certificate = load_certificate(file_path)
        return certificate.public_key()
    except Exception as e:
        print(f"Failed to load public key from certificate {file_path}: {e}")
        return None

def generate_symmetric_key():
    return secrets.token_bytes(32)

def rsa_encrypt(public_key, symmetric_key):
    try:
        encrypted_key = public_key.encrypt(
            symmetric_key,
            padding.OAEP(mgf=padding.MGF1(algorithm=hashes.SHA256()),
                         algorithm=hashes.SHA256(),
                         label=None)
        )
        return encrypted_key
    except Exception as e:
        print(f"Failed to encrypt with RSA: {e}")
        return None

def rsa_decrypt(private_key, encrypted_key):
    try:
        decrypted_key = private_key.decrypt(
            encrypted_key,
            padding.OAEP(mgf=padding.MGF1(algorithm=hashes.SHA256()),
                         algorithm=hashes.SHA256(),
                         label=None)
        )
        return decrypted_key
    except Exception as e:
        print(f"Failed to decrypt with RSA: {e}")
        return None

def ecc_key_exchange(private_key, peer_public_key):
    try:
        shared_key = private_key.exchange(ec.ECDH(), peer_public_key)
        derived_key = HKDF(algorithm=hashes.SHA256(), length=32, salt=None,
                           info=b'handshake data').derive(shared_key)
        return derived_key
    except Exception as e:
        print(f"Failed to perform ECC key exchange: {e}")
        return None

def key_exchange():
    # Prompt user to enter the certificate file name
    cert_name = input("Enter the name of the certificate file (e.g., test_certificate.pem): ").strip()
    cert_path = os.path.join(os.path.dirname(__file__), '..', 'certificates', cert_name)
    crl_path = os.path.join(os.path.dirname(__file__), '..', 'crl', 'crl.pem')

    print(f"Certificate path: {cert_path}")
    print(f"CRL path: {crl_path}")

    # Verify the certificate
    if not verify_certificate(cert_path, crl_path):
        print(f"The certificate {cert_path} is invalid, expired, or revoked.")
        return

    # Determine the certificate type (ECC or RSA) based on the public key
    public_key = load_public_key_from_cert(cert_path)
    if isinstance(public_key, rsa.RSAPublicKey):
        cert_type = "RSA"
    elif isinstance(public_key, ec.EllipticCurvePublicKey):
        cert_type = "ECC"
    else:
        print("Unsupported certificate type.")
        return

    # Paths to the keys
    private_key_path = os.path.join(os.path.dirname(__file__), '..', 'certificates', f"{cert_name.replace('certificate', 'private_key')}")

    print(f"Private key path: {private_key_path}")

    # Load the private key
    private_key = load_private_key(private_key_path)
    if not private_key:
        print(f"Failed to load the private key from {private_key_path}. Exiting.")
        return

    # Perform key exchange
    if cert_type == 'ECC':
        symmetric_key = ecc_key_exchange(private_key, public_key)
        if symmetric_key:
            print(f"Exchanged symmetric key using ECC: {symmetric_key.hex()}")
    elif cert_type == 'RSA':
        symmetric_key = generate_symmetric_key()
        encrypted_symmetric_key = rsa_encrypt(public_key, symmetric_key)
        decrypted_symmetric_key = rsa_decrypt(private_key, encrypted_symmetric_key)
        if encrypted_symmetric_key and decrypted_symmetric_key:
            print(f"Exchanged symmetric key using RSA: {decrypted_symmetric_key.hex()}")

            # Verify the keys match
            if decrypted_symmetric_key != symmetric_key:
                print("RSA keys do not match!")
            else:
                print("Key exchange successful!")

def main():
    key_exchange()

if __name__ == "__main__":
    main()
