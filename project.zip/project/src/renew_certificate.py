import os
import datetime
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa, ec
from cryptography.hazmat.backends import default_backend

def load_certificate(file_path):
    with open(file_path, "rb") as f:
        cert_data = f.read()
    try:
        return x509.load_pem_x509_certificate(cert_data, default_backend())
    except ValueError:
        if "PRIVATE KEY" not in str(cert_data):
            print(f"Error: The file {file_path} is not a valid certificate.")
        return None

def load_private_key(file_path):
    with open(file_path, "rb") as f:
        key_data = f.read()
    return serialization.load_pem_private_key(key_data, password=None, backend=default_backend())

def load_crl(file_path):
    if os.path.exists(file_path):
        with open(file_path, "rb") as f:
            crl_data = f.read()
        try:
            return x509.load_pem_x509_crl(crl_data)
        except ValueError:
            print("Failed to load CRL.")
            return None
    return None

def renew_certificate(cert_path, root_cert, root_key, crl):
    issued_cert = load_certificate(cert_path)
    if not issued_cert:
        return
    
    # Check if the certificate is revoked
    if crl and crl.get_revoked_certificate_by_serial_number(issued_cert.serial_number):
        print(f"Certificate {cert_path} is revoked.")
        return
    
    if issued_cert.not_valid_after_utc <= datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(days=30):
        print(f"Renewing certificate: {cert_path}")

        # Create a new certificate builder
        builder = x509.CertificateBuilder().subject_name(
            issued_cert.subject
        ).issuer_name(
            root_cert.subject
        ).public_key(
            issued_cert.public_key()
        ).serial_number(
            x509.random_serial_number()
        ).not_valid_before(
            datetime.datetime.utcnow()
        ).not_valid_after(
            datetime.datetime.utcnow() + datetime.timedelta(days=365)
        ).add_extension(
            x509.BasicConstraints(ca=False, path_length=None), critical=True,
        )

        # Sign the new certificate with the root private key
        renewed_cert = builder.sign(private_key=root_key, algorithm=hashes.SHA256(), backend=default_backend())

        # Save the renewed certificate
        renewed_cert_path = cert_path.replace(".pem", "_renewed.pem")
        with open(renewed_cert_path, "wb") as f:
            f.write(renewed_cert.public_bytes(serialization.Encoding.PEM))

        print(f"Renewed certificate saved to: {renewed_cert_path}")
    else:
        print(f"Certificate {cert_path} does not need renewal yet.")

def main():
    cert_dir = os.path.join(os.path.dirname(__file__), '..', 'certificates')
    crl_dir = os.path.join(os.path.dirname(__file__), '..', 'crl')
    
    root_cert_path = os.path.join(cert_dir, "root_certificate.pem")
    root_key_path = os.path.join(cert_dir, "root_private_key.pem")
    crl_path = os.path.join(crl_dir, "crl.pem")

    if not os.path.exists(root_cert_path):
        print("Root certificate not found. Please ensure that the root certificate exists in the 'certificates' directory.")
        return

    if not os.path.exists(root_key_path):
        print("Root private key not found. Please ensure that the root private key exists in the 'certificates' directory.")
        return

    if not os.path.exists(crl_path):
        print("CRL not found. Please ensure that the CRL exists in the 'crl' directory.")
        return

    root_certificate = load_certificate(root_cert_path)
    root_key = load_private_key(root_key_path)
    crl = load_crl(crl_path)

    for cert_name in os.listdir(cert_dir):
        cert_path = os.path.join(cert_dir, cert_name)
        if cert_name.endswith(".pem") and "private_key" not in cert_name and "renewed" not in cert_name:
            renew_certificate(cert_path, root_certificate, root_key, crl)

if __name__ == "__main__":
    main()
