
import os
import datetime
from cryptography import x509
from cryptography.hazmat.primitives.asymmetric import rsa, ec
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.backends import default_backend

def load_certificate(file_path):
    with open(file_path, "rb") as f:
        cert_data = f.read()
    return x509.load_pem_x509_certificate(cert_data, default_backend())

def load_crl(file_path):
    if os.path.exists(file_path):
        with open(file_path, "rb") as f:
            crl_data = f.read()
        try:
            return x509.load_pem_x509_crl(crl_data)
        except ValueError:
            print("Failed to load CRL.")
            return None
    return None

def verify_certificate_issued_by_root(issued_cert, root_cert, crl, report):
    # Check if the issuer of the issued certificate is the root certificate
    if issued_cert.issuer != root_cert.subject:
        report.append("Issuer mismatch: The issued certificate is not signed by the root certificate.")
        return False

    # Check if the certificate is revoked
    if crl and crl.get_revoked_certificate_by_serial_number(issued_cert.serial_number):
        report.append(f"Certificate {issued_cert.serial_number} is revoked.")
        return False

    # Verify the signature
    try:
        root_cert.public_key().verify(
            issued_cert.signature,
            issued_cert.tbs_certificate_bytes,
            ec.ECDSA(hashes.SHA256())
        )
        report.append(f"The issued certificate is signed by the root certificate '{root_cert.subject}'.")
    except Exception as e:
        report.append(f"Signature verification failed: {e}")
        return False

    return True

def verify_certificate_contents(cert, report):
    # Check if the certificate is expired
    if cert.not_valid_after_utc <= datetime.datetime.now(datetime.timezone.utc):
        report.append("The certificate is expired.")
        return False

    # Check if the certificate contains the public key
    if not cert.public_key():
        report.append("The certificate does not contain a public key.")
        return False
    else:
        pub_key = cert.public_key().public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        ).decode('utf-8')
        report.append(f"Public Key: \n{pub_key}")

    # Check if the certificate contains the serial number
    if not cert.serial_number:
        report.append("The certificate does not contain a serial number.")
        return False
    else:
        report.append(f"Serial Number: {cert.serial_number}")

    # Check if the certificate contains the expiration date
    if not cert.not_valid_after_utc:
        report.append("The certificate does not contain an expiration date.")
        return False
    else:
        expiration_status = "valid" if cert.not_valid_after_utc > datetime.datetime.now(datetime.timezone.utc) else "expired"
        report.append(f"Expiration Date: {cert.not_valid_after_utc} ({expiration_status})")

    # Add encryption type
    pubkey = cert.public_key()
    if isinstance(pubkey, rsa.RSAPublicKey):
        report.append("Encryption Type: RSA")
    elif isinstance(pubkey, ec.EllipticCurvePublicKey):
        report.append("Encryption Type: ECC")
    else:
        report.append("Encryption Type: Unknown")

    # Add issued to name
    report.append(f"Issued To: {cert.subject}")

    return True

def save_report(report, cert_name):
    # Ensure the 'valid' directory exists
    valid_dir = os.path.join(os.path.dirname(__file__), '..', 'valid')
    os.makedirs(valid_dir, exist_ok=True)

    report_file_name = f"Valid_{cert_name.replace('.pem', '')}.txt"
    report_file_path = os.path.join(valid_dir, report_file_name)

    # Add the date of report generation
    report_date = f"Report generated on: {datetime.datetime.now(datetime.timezone.utc)}"
    report.insert(1, report_date)

    with open(report_file_path, 'w', encoding='utf-8') as f:
        for item in report:
            f.write(item + "\n")
    print(f"Validation report saved to {report_file_path}")

def main():
    cert_dir = os.path.join(os.path.dirname(__file__), '..', 'certificates')
    crl_dir = os.path.join(os.path.dirname(__file__), '..', 'crl')
    
    root_cert_path = os.path.join(cert_dir, "root_certificate.pem")
    crl_path = os.path.join(crl_dir, "crl.pem")
    issued_cert_name = input("Enter the name of the issued certificate file (e.g., issued_certificate.pem): ").strip()
    issued_cert_path = os.path.join(cert_dir, issued_cert_name)

    if not os.path.exists(root_cert_path):
        print("Root certificate not found. Please ensure that the root certificate exists in the 'certificates' directory.")
        return

    if not os.path.exists(crl_path):
        print("CRL not found. Please ensure that the CRL exists in the 'crl' directory.")
        return

    if not os.path.exists(issued_cert_path):
        print(f"Issued certificate {issued_cert_name} not found. Please ensure that the issued certificate exists in the 'certificates' directory.")
        return

    root_certificate = load_certificate(root_cert_path)
    crl = load_crl(crl_path)
    issued_certificate = load_certificate(issued_cert_path)

    report = [f"Validation Report for: {issued_cert_name}"]

    # Verify that the issued certificate is signed by the root certificate and is not revoked
    if verify_certificate_issued_by_root(issued_certificate, root_certificate, crl, report):
        # Verify the contents of the issued certificate
        verify_certificate_contents(issued_certificate, report)

    # Save the validation report to a file
    save_report(report, issued_cert_name)

    # Print the validation report to the terminal (excluding public key)
    print("\nValidation Report:")
    for item in report:
        if "Public Key:" not in item:
            print(item)

if __name__ == "__main__":
    main()
