import os
import datetime
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa, ec

def load_certificate(file_path):
    with open(file_path, "rb") as f:
        cert_data = f.read()
    return x509.load_pem_x509_certificate(cert_data)

def load_private_key(file_path):
    with open(file_path, "rb") as f:
        key_data = f.read()
    return serialization.load_pem_private_key(key_data, password=None)

def load_crl(file_path):
    if os.path.exists(file_path):
        with open(file_path, "rb") as f:
            crl_data = f.read()
        try:
            return x509.load_pem_x509_crl(crl_data)
        except ValueError:
            print("Failed to load existing CRL. Creating a new one.")
            return None
    return None

def generate_crl():
    # Load the root certificate and private key
    root_cert_path = os.path.join(os.path.dirname(__file__), '..', 'certificates', 'root_certificate.pem')
    root_key_path = os.path.join(os.path.dirname(__file__), '..', 'certificates', 'root_private_key.pem')
    root_cert = load_certificate(root_cert_path)
    root_key = load_private_key(root_key_path)

    # Ensure the 'crl' directory exists
    crl_dir = os.path.join(os.path.dirname(__file__), '..', 'crl')
    os.makedirs(crl_dir, exist_ok=True)
    crl_path = os.path.join(crl_dir, 'crl.pem')

    # Load existing CRL if it exists
    crl_builder = x509.CertificateRevocationListBuilder()
    existing_crl = load_crl(crl_path)
    if existing_crl:
        crl_builder = crl_builder.issuer_name(existing_crl.issuer)
        crl_builder = crl_builder.last_update(existing_crl.last_update_utc)
        crl_builder = crl_builder.next_update(datetime.datetime.utcnow() + datetime.timedelta(days=30))
        for revoked_cert in existing_crl:
            crl_builder = crl_builder.add_revoked_certificate(revoked_cert)
    else:
        crl_builder = crl_builder.issuer_name(root_cert.subject)
        crl_builder = crl_builder.last_update(datetime.datetime.utcnow())
        crl_builder = crl_builder.next_update(datetime.datetime.utcnow() + datetime.timedelta(days=30))

    # Add revoked certificates
    serial_numbers = input("Enter the serial numbers of the certificates to revoke (comma-separated): ").split(',')
    for serial_number in serial_numbers:
        serial_number = int(serial_number.strip())
        revocation_date = datetime.datetime.utcnow()
        revoked_cert = x509.RevokedCertificateBuilder().serial_number(serial_number).revocation_date(revocation_date).build()
        crl_builder = crl_builder.add_revoked_certificate(revoked_cert)

    # Sign and build the CRL
    crl = crl_builder.sign(private_key=root_key, algorithm=hashes.SHA256())

    # Save the CRL to a file
    with open(crl_path, "wb") as f:
        f.write(crl.public_bytes(serialization.Encoding.PEM))

    print(f"CRL generated and saved to {crl_path}")

if __name__ == "__main__":
    generate_crl()
