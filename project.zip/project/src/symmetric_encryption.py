from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding as sym_padding
import secrets

def encrypt_data(symmetric_key, data):
    iv = secrets.token_bytes(16)
    cipher = Cipher(algorithms.AES(symmetric_key), modes.CBC(iv))
    encryptor = cipher.encryptor()
    
    padder = sym_padding.PKCS7(algorithms.AES.block_size).padder()
    padded_data = padder.update(data) + padder.finalize()
    
    encrypted_data = encryptor.update(padded_data) + encryptor.finalize()
    return iv + encrypted_data

def decrypt_data(symmetric_key, encrypted_data):
    iv = encrypted_data[:16]
    cipher = Cipher(algorithms.AES(symmetric_key), modes.CBC(iv))
    decryptor = cipher.decryptor()
    
    padded_data = decryptor.update(encrypted_data[16:]) + decryptor.finalize()
    unpadder = sym_padding.PKCS7(algorithms.AES.block_size).unpadder()
    data = unpadder.update(padded_data) + unpadder.finalize()
    
    return data

if __name__ == "__main__":
    # Get user inputs
    text_to_encrypt = input("Enter the text to encrypt: ").encode()
    encryption_key = input("Enter the encryption key (hex format): ")
    encryption_key = bytes.fromhex(encryption_key)
    
    # Encrypt the data
    encrypted_data = encrypt_data(encryption_key, text_to_encrypt)
    encrypted_data_hex = encrypted_data.hex()
    print(f"Encrypted data: {encrypted_data_hex}")
    
    # Get user input for decryption
    decryption_key = input("Enter the decryption key (hex format): ")
    decryption_key = bytes.fromhex(decryption_key)
    encrypted_data_to_decrypt = bytes.fromhex(encrypted_data_hex)
    
    # Decrypt the data
    decrypted_data = decrypt_data(decryption_key, encrypted_data_to_decrypt)
    decrypted_text = decrypted_data.decode()
    print(f"Decrypted data: {decrypted_text}")
